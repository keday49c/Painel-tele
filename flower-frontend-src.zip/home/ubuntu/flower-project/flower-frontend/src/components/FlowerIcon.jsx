import React from 'react'

const FlowerIcon = ({ className = "w-8 h-8", color = "currentColor" }) => {
  return (
    <svg 
      viewBox="0 0 100 100" 
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Flor estilizada baseada no logotipo fornecido */}
      <defs>
        <linearGradient id="flowerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#EC4899" />
          <stop offset="50%" stopColor="#8B5CF6" />
          <stop offset="100%" stopColor="#6366F1" />
        </linearGradient>
      </defs>
      
      {/* Pétalas superiores */}
      <circle cx="35" cy="25" r="12" fill="url(#flowerGradient)" opacity="0.9" />
      <circle cx="65" cy="25" r="12" fill="url(#flowerGradient)" opacity="0.9" />
      
      {/* Pétalas laterais */}
      <circle cx="20" cy="45" r="12" fill="url(#flowerGradient)" opacity="0.9" />
      <circle cx="80" cy="45" r="12" fill="url(#flowerGradient)" opacity="0.9" />
      
      {/* Pétalas inferiores */}
      <circle cx="35" cy="65" r="12" fill="url(#flowerGradient)" opacity="0.9" />
      <circle cx="65" cy="65" r="12" fill="url(#flowerGradient)" opacity="0.9" />
      
      {/* Centro da flor */}
      <circle cx="50" cy="45" r="8" fill="url(#flowerGradient)" />
      
      {/* Caule */}
      <rect x="47" y="53" width="6" height="25" fill="url(#flowerGradient)" rx="3" />
      
      {/* Folhas */}
      <ellipse cx="35" cy="70" rx="8" ry="4" fill="url(#flowerGradient)" opacity="0.8" transform="rotate(-30 35 70)" />
      <ellipse cx="65" cy="70" rx="8" ry="4" fill="url(#flowerGradient)" opacity="0.8" transform="rotate(30 65 70)" />
    </svg>
  )
}

export default FlowerIcon

