import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark,
  MoreHorizontal,
  Users
} from 'lucide-react'

export default function PostCard({ post }) {
  const [isLiked, setIsLiked] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const [likesCount, setLikesCount] = useState(post?.likes || 24)

  const handleLike = () => {
    setIsLiked(!isLiked)
    setLikesCount(prev => isLiked ? prev - 1 : prev + 1)
  }

  const handleSave = () => {
    setIsSaved(!isSaved)
  }

  // Dados de exemplo se não houver post
  const postData = post || {
    id: 1,
    user: {
      name: 'Maria Silva',
      username: '@maria_empreende',
      avatar: null
    },
    community: 'Empreendedoras',
    content: 'Acabei de lançar meu primeiro produto digital! 🚀 Depois de meses de planejamento e desenvolvimento, finalmente está no ar. A jornada empreendedora não é fácil, mas cada pequena vitória vale a pena. Obrigada a todas vocês pelo apoio e pelas dicas valiosas! 💜',
    image: null,
    timestamp: '2h',
    likes: 24,
    comments: 8,
    shares: 3
  }

  return (
    <Card className="mb-6 hover:shadow-md transition-shadow duration-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={postData.user.avatar} />
              <AvatarFallback className="bg-primary text-primary-foreground">
                {postData.user.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="font-semibold text-sm">{postData.user.name}</h4>
                <span className="text-xs text-gray-500">{postData.user.username}</span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-gray-500">
                <Users className="h-3 w-3" />
                <span>{postData.community}</span>
                <span>•</span>
                <span>{postData.timestamp}</span>
              </div>
            </div>
          </div>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        {/* Post Content */}
        <div className="mb-4">
          <p className="text-gray-900 leading-relaxed">{postData.content}</p>
        </div>

        {/* Post Image (if exists) */}
        {postData.image && (
          <div className="mb-4 rounded-lg overflow-hidden">
            <img 
              src={postData.image} 
              alt="Post content" 
              className="w-full h-auto object-cover"
            />
          </div>
        )}

        {/* Engagement Stats */}
        <div className="flex items-center justify-between text-sm text-gray-500 mb-3 pt-3 border-t border-gray-100">
          <span>{likesCount} curtidas</span>
          <div className="flex space-x-4">
            <span>{postData.comments} comentários</span>
            <span>{postData.shares} compartilhamentos</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-2 border-t border-gray-100">
          <div className="flex space-x-1">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLike}
              className={`flex items-center space-x-2 ${isLiked ? 'text-red-500' : 'text-gray-600'}`}
            >
              <Heart className={`h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
              <span>Curtir</span>
            </Button>
            <Button variant="ghost" size="sm" className="flex items-center space-x-2 text-gray-600">
              <MessageCircle className="h-4 w-4" />
              <span>Comentar</span>
            </Button>
            <Button variant="ghost" size="sm" className="flex items-center space-x-2 text-gray-600">
              <Share2 className="h-4 w-4" />
              <span>Compartilhar</span>
            </Button>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleSave}
            className={`${isSaved ? 'text-primary' : 'text-gray-600'}`}
          >
            <Bookmark className={`h-4 w-4 ${isSaved ? 'fill-current' : ''}`} />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

