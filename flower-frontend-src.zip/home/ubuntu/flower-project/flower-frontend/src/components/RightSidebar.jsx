import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { 
  TrendingUp, 
  Users, 
  Calendar,
  Star,
  Plus,
  ExternalLink
} from 'lucide-react'

export default function RightSidebar() {
  const trendingTopics = [
    { tag: '#EmpreendedorismoFeminino', posts: '2.3k posts' },
    { tag: '#MaesEmpreendedoras', posts: '1.8k posts' },
    { tag: '#BemEstarMental', posts: '3.1k posts' },
    { tag: '#TechWomen', posts: '1.5k posts' },
    { tag: '#FinancasPessoais', posts: '2.7k posts' }
  ]

  const suggestedUsers = [
    {
      name: 'Ana Costa',
      username: '@ana_coach',
      bio: 'Coach de carreira e mentora',
      followers: '12k',
      avatar: null
    },
    {
      name: 'Juliana Tech',
      username: '@ju_dev',
      bio: 'Desenvolvedora Full Stack',
      followers: '8.5k',
      avatar: null
    },
    {
      name: 'Carla Finanças',
      username: '@carla_money',
      bio: 'Consultora financeira',
      followers: '15k',
      avatar: null
    }
  ]

  const upcomingEvents = [
    {
      title: 'Workshop: Primeiros Passos no Empreendedorismo',
      date: 'Amanhã, 19h',
      attendees: 234
    },
    {
      title: 'Live: Equilibrio entre Maternidade e Carreira',
      date: 'Sex, 20h',
      attendees: 156
    },
    {
      title: 'Masterclass: Investimentos para Iniciantes',
      date: 'Sáb, 14h',
      attendees: 89
    }
  ]

  return (
    <aside className="hidden xl:block xl:w-80 xl:fixed xl:right-0 xl:top-16 xl:h-screen xl:overflow-y-auto xl:pt-6 xl:pb-4">
      <div className="px-4 space-y-6">
        
        {/* Trending Topics */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-primary" />
              Trending
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              {trendingTopics.map((topic, index) => (
                <div key={index} className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-lg cursor-pointer">
                  <div>
                    <p className="font-medium text-sm text-primary">{topic.tag}</p>
                    <p className="text-xs text-gray-500">{topic.posts}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Suggested Users */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center">
              <Users className="h-5 w-5 mr-2 text-primary" />
              Sugestões para Seguir
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-4">
              {suggestedUsers.map((user, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user.avatar} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {user.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm truncate">{user.name}</p>
                        <p className="text-xs text-gray-500">{user.username}</p>
                        <p className="text-xs text-gray-600 mt-1">{user.bio}</p>
                        <p className="text-xs text-gray-500">{user.followers} seguidores</p>
                      </div>
                      <Button size="sm" variant="outline" className="ml-2">
                        <Plus className="h-3 w-3 mr-1" />
                        Seguir
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Events */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-primary" />
              Próximos Eventos
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-4">
              {upcomingEvents.map((event, index) => (
                <div key={index} className="p-3 border border-gray-200 rounded-lg hover:border-primary transition-colors cursor-pointer">
                  <h4 className="font-medium text-sm mb-1">{event.title}</h4>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{event.date}</span>
                    <span>{event.attendees} participantes</span>
                  </div>
                  <Button size="sm" variant="ghost" className="mt-2 p-0 h-auto text-primary">
                    Ver detalhes
                    <ExternalLink className="h-3 w-3 ml-1" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Premium Promotion */}
        <Card className="bg-gradient-to-br from-pink-50 to-purple-50 border-pink-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <Star className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
              <h4 className="font-semibold text-gray-900 mb-1">Flower Premium</h4>
              <p className="text-sm text-gray-600 mb-3">
                ✨ Acesso a trilhas exclusivas<br/>
                💬 Mentoria personalizada<br/>
                🎯 Conteúdo sem anúncios
              </p>
              <Button className="w-full">
                Experimentar Grátis
              </Button>
            </div>
          </CardContent>
        </Card>

      </div>
    </aside>
  )
}

