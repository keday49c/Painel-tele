import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { 
  Home, 
  Users, 
  MessageSquare, 
  BookOpen, 
  Star, 
  Settings,
  Plus,
  TrendingUp,
  Heart,
  Briefcase
} from 'lucide-react'

export default function Sidebar() {
  const menuItems = [
    { icon: Home, label: 'Início', active: true },
    { icon: Users, label: 'Comunidades', count: 5 },
    { icon: MessageSquare, label: 'Mensagens', count: 2 },
    { icon: BookOpen, label: 'Trilhas de Desenvolvimento' },
    { icon: Star, label: 'Favoritos' },
    { icon: TrendingUp, label: 'Trending' },
  ]

  const communities = [
    { name: 'Empreendedoras', members: '2.3k', color: 'bg-pink-500' },
    { name: 'Mães Conectadas', members: '1.8k', color: 'bg-purple-500' },
    { name: 'Bem-estar Mental', members: '3.1k', color: 'bg-green-500' },
    { name: 'Carreira Tech', members: '1.5k', color: 'bg-blue-500' },
  ]

  return (
    <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 lg:pt-16 bg-gray-50 border-r border-gray-200">
      <div className="flex-1 flex flex-col min-h-0 pt-6 pb-4 overflow-y-auto">
        <div className="flex-1 px-4 space-y-6">
          {/* Main Navigation */}
          <nav className="space-y-2">
            {menuItems.map((item, index) => (
              <Button
                key={index}
                variant={item.active ? "default" : "ghost"}
                className={`w-full justify-start ${item.active ? 'bg-primary text-primary-foreground' : ''}`}
              >
                <item.icon className="mr-3 h-4 w-4" />
                {item.label}
                {item.count && (
                  <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-1">
                    {item.count}
                  </span>
                )}
              </Button>
            ))}
          </nav>

          {/* Communities Section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-gray-700">Minhas Comunidades</h3>
              <Button variant="ghost" size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-2">
              {communities.map((community, index) => (
                <div key={index} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-100 cursor-pointer">
                  <div className={`w-3 h-3 rounded-full ${community.color}`}></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{community.name}</p>
                    <p className="text-xs text-gray-500">{community.members} membros</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Premium Card */}
          <Card className="p-4 bg-gradient-to-br from-pink-50 to-purple-50 border-pink-200">
            <div className="text-center">
              <Heart className="h-8 w-8 text-pink-500 mx-auto mb-2" />
              <h4 className="text-sm font-semibold text-gray-900 mb-1">Flower Premium</h4>
              <p className="text-xs text-gray-600 mb-3">
                Acesse conteúdo exclusivo, trilhas avançadas e muito mais!
              </p>
              <Button size="sm" className="w-full">
                Assinar Premium
              </Button>
            </div>
          </Card>
        </div>

        {/* Settings */}
        <div className="px-4 pb-4">
          <Button variant="ghost" className="w-full justify-start">
            <Settings className="mr-3 h-4 w-4" />
            Configurações
          </Button>
        </div>
      </div>
    </aside>
  )
}

