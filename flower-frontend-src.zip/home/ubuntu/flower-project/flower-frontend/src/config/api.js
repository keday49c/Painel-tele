// Configuração da API
const API_BASE_URL = 'https://8080-i4fv7vsgtrpi0r8f6g2o3-ba9e4c4c.manusvm.computer/api'

export const apiConfig = {
  baseURL: API_BASE_URL,
  endpoints: {
    auth: {
      register: '/auth/register',
      login: '/auth/login',
      refresh: '/auth/refresh'
    },
    user: {
      profile: '/user/profile',
      update: '/user/update'
    },
    posts: {
      feed: '/posts/feed',
      create: '/posts',
      like: '/posts/{id}/like'
    },
    communities: {
      list: '/communities',
      join: '/communities/{id}/join'
    }
  }
}

// Função helper para fazer requisições
export const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`
  
  const defaultOptions = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers
    }
  }

  // Adicionar token de autorização se disponível
  const token = localStorage.getItem('flower_token')
  if (token) {
    defaultOptions.headers.Authorization = `Bearer ${token}`
  }

  const response = await fetch(url, {
    ...defaultOptions,
    ...options
  })

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`)
  }

  return response.json()
}

export default apiConfig

