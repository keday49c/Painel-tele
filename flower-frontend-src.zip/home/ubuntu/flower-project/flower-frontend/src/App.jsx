import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Sidebar from './components/Sidebar'
import Feed from './components/Feed'
import RightSidebar from './components/RightSidebar'
import LandingPage from './components/LandingPage'
import LoginForm from './components/LoginForm'
import RegisterForm from './components/RegisterForm'
import './App.css'

function App() {
  const [currentView, setCurrentView] = useState('landing') // 'landing', 'login', 'register', 'app'
  const [user, setUser] = useState(null)
  const [prefilledEmail, setPrefilledEmail] = useState('')

  useEffect(() => {
    // Verificar se há token salvo
    const token = localStorage.getItem('flower_token')
    const savedUser = localStorage.getItem('flower_user')
    
    if (token && savedUser) {
      setUser(JSON.parse(savedUser))
      setCurrentView('app')
    }
  }, [])

  const handleLogin = (userData) => {
    setUser(userData)
    setCurrentView('app')
  }

  const handleLogout = () => {
    localStorage.removeItem('flower_token')
    localStorage.removeItem('flower_user')
    setUser(null)
    setCurrentView('landing')
  }

  const handleShowLogin = () => {
    setCurrentView('login')
  }

  const handleShowRegister = (email = '') => {
    setPrefilledEmail(email)
    setCurrentView('register')
  }

  const handleBackToLanding = () => {
    setCurrentView('landing')
  }

  const handleSwitchToLogin = () => {
    setCurrentView('login')
  }

  const handleSwitchToRegister = () => {
    setCurrentView('register')
  }

  // Renderizar baseado no estado atual
  if (currentView === 'login') {
    return (
      <LoginForm 
        onLogin={handleLogin}
        onBack={handleBackToLanding}
        onSwitchToRegister={handleSwitchToRegister}
      />
    )
  }

  if (currentView === 'register') {
    return (
      <RegisterForm 
        onRegister={handleLogin}
        onBack={handleBackToLanding}
        onSwitchToLogin={handleSwitchToLogin}
        prefilledEmail={prefilledEmail}
      />
    )
  }

  if (currentView === 'landing') {
    return (
      <LandingPage 
        onShowLogin={handleShowLogin}
        onShowRegister={handleShowRegister}
      />
    )
  }

  // App principal (usuário logado)
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <Header user={user} onLogout={handleLogout} />
        
        {/* Main Layout */}
        <div className="flex">
          {/* Left Sidebar */}
          <Sidebar />
          
          {/* Main Content */}
          <main className="flex-1 lg:ml-64 xl:mr-80">
            <div className="px-4 sm:px-6 lg:px-8 py-8">
              <Routes>
                <Route path="/" element={<Feed />} />
                <Route path="/communities" element={<div>Comunidades</div>} />
                <Route path="/messages" element={<div>Mensagens</div>} />
                <Route path="/learning" element={<div>Trilhas</div>} />
              </Routes>
            </div>
          </main>
          
          {/* Right Sidebar */}
          <RightSidebar />
        </div>
      </div>
    </Router>
  )
}

export default App
