import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Image, 
  Video, 
  Smile, 
  MapPin, 
  Users,
  X
} from 'lucide-react'

export default function CreatePost() {
  const [postContent, setPostContent] = useState('')
  const [selectedCommunity, setSelectedCommunity] = useState('')
  const [isExpanded, setIsExpanded] = useState(false)

  const communities = [
    'Empreendedoras',
    'Mães Conectadas', 
    'Bem-estar Mental',
    'Carreira Tech',
    'Finanças Pessoais'
  ]

  const handleSubmit = () => {
    if (postContent.trim()) {
      // Aqui seria feita a chamada para a API
      console.log('Novo post:', {
        content: postContent,
        community: selectedCommunity
      })
      setPostContent('')
      setSelectedCommunity('')
      setIsExpanded(false)
    }
  }

  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <div className="flex space-x-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src="" />
            <AvatarFallback className="bg-primary text-primary-foreground">
              EU
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <Textarea
              placeholder="O que você gostaria de compartilhar hoje?"
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              onFocus={() => setIsExpanded(true)}
              className="min-h-[80px] resize-none border-none shadow-none focus:ring-0 text-base placeholder:text-gray-500"
            />

            {isExpanded && (
              <div className="mt-4 space-y-4">
                {/* Community Selection */}
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-gray-500" />
                  <select 
                    value={selectedCommunity}
                    onChange={(e) => setSelectedCommunity(e.target.value)}
                    className="text-sm border border-gray-300 rounded-md px-3 py-1 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="">Selecionar comunidade (opcional)</option>
                    {communities.map((community, index) => (
                      <option key={index} value={community}>{community}</option>
                    ))}
                  </select>
                </div>

                {/* Media Options */}
                <div className="flex items-center justify-between">
                  <div className="flex space-x-4">
                    <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
                      <Image className="h-4 w-4 mr-2" />
                      Foto
                    </Button>
                    <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
                      <Video className="h-4 w-4 mr-2" />
                      Vídeo
                    </Button>
                    <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
                      <Smile className="h-4 w-4 mr-2" />
                      Emoji
                    </Button>
                    <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
                      <MapPin className="h-4 w-4 mr-2" />
                      Local
                    </Button>
                  </div>

                  <div className="flex space-x-2">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => {
                        setIsExpanded(false)
                        setPostContent('')
                        setSelectedCommunity('')
                      }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                    <Button 
                      onClick={handleSubmit}
                      disabled={!postContent.trim()}
                      className="px-6"
                    >
                      Publicar
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

