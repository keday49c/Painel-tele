import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Users, Shield, Sparkles, ArrowRight, CheckCircle, Star } from 'lucide-react'
import FlowerIcon from './FlowerIcon'

export default function LandingPage({ onShowLogin, onShowRegister }) {
  const [email, setEmail] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    // Redirecionar para cadastro com email preenchido
    onShowRegister(email)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-pink-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <FlowerIcon className="w-8 h-8" />
              <span className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                Flower
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                className="text-purple-700 hover:text-purple-900"
                onClick={onShowLogin}
              >
                Entrar
              </Button>
              <Button 
                className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                onClick={onShowRegister}
              >
                Cadastrar
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <Badge className="mb-6 bg-pink-100 text-pink-800 hover:bg-pink-200">
            🌸 Exclusivo para Mulheres
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold mb-6">
            <span className="bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
              Floresça
            </span>
            <br />
            <span className="text-gray-800">com a Flower!</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
            A primeira rede social dedicada exclusivamente às mulheres. 
            Um espaço seguro para compartilhar ideias, experiências e projetos.
          </p>
          
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto mb-8">
            <Input
              type="email"
              placeholder="Seu melhor email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1"
              required
            />
            <Button type="submit" className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
              Começar Agora
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </form>
          
          <p className="text-sm text-gray-500">
            ✨ Verificação de identidade obrigatória • 100% seguro
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              Por que escolher a Flower?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Uma plataforma pensada especialmente para empoderar mulheres
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-pink-200 hover:shadow-lg transition-shadow">
              <CardHeader>
                <Shield className="w-12 h-12 text-pink-500 mb-4" />
                <CardTitle className="text-purple-800">100% Seguro</CardTitle>
                <CardDescription>
                  Verificação facial e validação de identidade garantem que apenas mulheres tenham acesso
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card className="border-purple-200 hover:shadow-lg transition-shadow">
              <CardHeader>
                <Users className="w-12 h-12 text-purple-500 mb-4" />
                <CardTitle className="text-purple-800">Comunidades</CardTitle>
                <CardDescription>
                  Conecte-se com mulheres que compartilham seus interesses e objetivos
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card className="border-indigo-200 hover:shadow-lg transition-shadow">
              <CardHeader>
                <Sparkles className="w-12 h-12 text-indigo-500 mb-4" />
                <CardTitle className="text-purple-800">IA Integrada</CardTitle>
                <CardDescription>
                  Ferramentas de inteligência artificial para potencializar seu crescimento pessoal e profissional
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-pink-600 mb-2">10K+</div>
              <div className="text-gray-600">Mulheres Conectadas</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-600 mb-2">500+</div>
              <div className="text-gray-600">Comunidades Ativas</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-indigo-600 mb-2">1M+</div>
              <div className="text-gray-600">Posts Compartilhados</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-pink-600 mb-2">98%</div>
              <div className="text-gray-600">Satisfação</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              O que nossas usuárias dizem
            </h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-pink-200">
              <CardContent className="pt-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Finalmente um espaço onde posso ser eu mesma e me conectar com outras mulheres incríveis!"
                </p>
                <div className="font-semibold text-purple-800">Maria Silva</div>
                <div className="text-sm text-gray-500">Empreendedora</div>
              </CardContent>
            </Card>
            
            <Card className="border-purple-200">
              <CardContent className="pt-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "As ferramentas de IA me ajudaram muito no meu desenvolvimento profissional."
                </p>
                <div className="font-semibold text-purple-800">Ana Costa</div>
                <div className="text-sm text-gray-500">Desenvolvedora</div>
              </CardContent>
            </Card>
            
            <Card className="border-indigo-200">
              <CardContent className="pt-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Um ambiente seguro e acolhedor para todas nós. Recomendo muito!"
                </p>
                <div className="font-semibold text-purple-800">Carla Santos</div>
                <div className="text-sm text-gray-500">Consultora</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Pronta para florescer?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Junte-se a milhares de mulheres que já estão transformando suas vidas na Flower
          </p>
          <Button 
            size="lg" 
            className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-8 py-3"
            onClick={onShowRegister}
          >
            Cadastrar Agora
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <FlowerIcon className="w-8 h-8" />
                <span className="text-2xl font-bold">Flower</span>
              </div>
              <p className="text-gray-400">
                Floresça com a Flower! A rede social exclusiva para mulheres.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Produto</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Recursos</a></li>
                <li><a href="#" className="hover:text-white">Comunidades</a></li>
                <li><a href="#" className="hover:text-white">Premium</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Empresa</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Sobre</a></li>
                <li><a href="#" className="hover:text-white">Carreiras</a></li>
                <li><a href="#" className="hover:text-white">Contato</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Contato</h3>
              <div className="text-gray-400 space-y-2">
                <p>David Ferreira Magalhães</p>
                <p>CEO & Fundador</p>
                <p>+55 21 97673-5366</p>
                <p>davidcruner@gmail.com</p>
                <p>Rio de Janeiro, Brasil</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Flower. Todos os direitos reservados. Floresça com a Flower!</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

