import { useState, useEffect } from 'react'
import CreatePost from './CreatePost'
import PostCard from './PostCard'
import { Button } from '@/components/ui/button'
import { RefreshCw } from 'lucide-react'

export default function Feed() {
  const [posts, setPosts] = useState([])
  const [isLoading, setIsLoading] = useState(false)

  // Dados de exemplo para demonstração
  const samplePosts = [
    {
      id: 1,
      user: {
        name: 'Maria Silva',
        username: '@maria_empreende',
        avatar: null
      },
      community: 'Empreendedoras',
      content: 'Acabei de lançar meu primeiro produto digital! 🚀 Depois de meses de planejamento e desenvolvimento, finalmente está no ar. A jornada empreendedora não é fácil, mas cada pequena vitória vale a pena. Obrigada a todas vocês pelo apoio e pelas dicas valiosas! 💜',
      image: null,
      timestamp: '2h',
      likes: 24,
      comments: 8,
      shares: 3
    },
    {
      id: 2,
      user: {
        name: 'Ana Costa',
        username: '@ana_coach',
        avatar: null
      },
      community: 'Bem-estar Mental',
      content: 'Lembrete importante: você não precisa ser perfeita para ser incrível! 💪 Hoje quero compartilhar 3 dicas que me ajudaram a lidar com a síndrome da impostora:\n\n1. Celebre suas pequenas vitórias\n2. Mantenha um diário de conquistas\n3. Cerque-se de pessoas que te apoiam\n\nQual dessas ressoa mais com você?',
      image: null,
      timestamp: '4h',
      likes: 67,
      comments: 23,
      shares: 12
    },
    {
      id: 3,
      user: {
        name: 'Juliana Tech',
        username: '@ju_dev',
        avatar: null
      },
      community: 'Carreira Tech',
      content: 'Acabei de terminar meu primeiro projeto em React! 🎉 Foi desafiador, mas aprendi muito sobre hooks, context API e gerenciamento de estado. Para quem está começando na programação: não desistam! Cada erro é uma oportunidade de aprender algo novo.',
      image: null,
      timestamp: '6h',
      likes: 45,
      comments: 15,
      shares: 8
    },
    {
      id: 4,
      user: {
        name: 'Carla Finanças',
        username: '@carla_money',
        avatar: null
      },
      community: 'Finanças Pessoais',
      content: 'Dica de ouro para quem quer começar a investir: comece pequeno, mas comece! 💰 Mesmo que seja R$ 50 por mês, o importante é criar o hábito. Lembrem-se: o tempo é o melhor amigo dos investimentos. Quanto antes começarem, melhor! Quem já investe? Compartilhem suas experiências! 📈',
      image: null,
      timestamp: '8h',
      likes: 89,
      comments: 34,
      shares: 21
    },
    {
      id: 5,
      user: {
        name: 'Beatriz Mãe',
        username: '@bia_mae',
        avatar: null
      },
      community: 'Mães Conectadas',
      content: 'Hoje foi um daqueles dias... Reunião importante de manhã, buscar as crianças na escola, ajudar com lição de casa, preparar jantar e ainda conseguir um tempinho para trabalhar no meu projeto pessoal. Às vezes me sinto uma malabarista! 🤹‍♀️ Como vocês fazem para equilibrar tudo?',
      image: null,
      timestamp: '10h',
      likes: 156,
      comments: 67,
      shares: 28
    }
  ]

  useEffect(() => {
    // Simular carregamento de posts
    setIsLoading(true)
    setTimeout(() => {
      setPosts(samplePosts)
      setIsLoading(false)
    }, 1000)
  }, [])

  const handleRefresh = () => {
    setIsLoading(true)
    setTimeout(() => {
      // Simular novos posts
      setPosts([...samplePosts])
      setIsLoading(false)
    }, 1000)
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Create Post */}
      <CreatePost />

      {/* Feed Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Feed Principal</h2>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefresh}
          disabled={isLoading}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Atualizar
        </Button>
      </div>

      {/* Posts */}
      {isLoading ? (
        <div className="space-y-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white rounded-lg border border-gray-200 p-6 animate-pulse">
              <div className="flex items-center space-x-3 mb-4">
                <div className="h-10 w-10 bg-gray-300 rounded-full"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-gray-300 rounded w-32"></div>
                  <div className="h-3 bg-gray-300 rounded w-24"></div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="h-4 bg-gray-300 rounded w-full"></div>
                <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                <div className="h-4 bg-gray-300 rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div>
          {posts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}

      {/* Load More */}
      {!isLoading && posts.length > 0 && (
        <div className="text-center mt-8">
          <Button variant="outline" className="px-8">
            Carregar mais posts
          </Button>
        </div>
      )}
    </div>
  )
}

