package com.flower.backend.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "profiles")
public class Profile {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;
    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @Column(columnDefinition = "TEXT")
    @Size(max = 1000, message = "Bio deve ter no máximo 1000 caracteres")
    private String bio;
    
    @Column(name = "profile_image_url", length = 500)
    private String profileImageUrl;
    
    @Column(length = 255)
    @Size(max = 255, message = "Localização deve ter no máximo 255 caracteres")
    private String location;
    
    @ElementCollection
    @CollectionTable(name = "profile_interests", joinColumns = @JoinColumn(name = "profile_id"))
    @Column(name = "interest")
    private List<String> interests;
    
    @Column(name = "privacy_settings", columnDefinition = "jsonb")
    private String privacySettings;
    
    @Column(name = "is_public_profile", nullable = false)
    private Boolean isPublicProfile = true;
    
    @Column(name = "allow_messages", nullable = false)
    private Boolean allowMessages = true;
    
    @Column(name = "show_online_status", nullable = false)
    private Boolean showOnlineStatus = true;
    
    @Column(name = "followers_count", nullable = false)
    private Integer followersCount = 0;
    
    @Column(name = "following_count", nullable = false)
    private Integer followingCount = 0;
    
    @Column(name = "posts_count", nullable = false)
    private Integer postsCount = 0;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    // Constructors
    public Profile() {}
    
    public Profile(User user) {
        this.user = user;
    }
    
    // Getters and Setters
    public UUID getId() {
        return id;
    }
    
    public void setId(UUID id) {
        this.id = id;
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public String getBio() {
        return bio;
    }
    
    public void setBio(String bio) {
        this.bio = bio;
    }
    
    public String getProfileImageUrl() {
        return profileImageUrl;
    }
    
    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public List<String> getInterests() {
        return interests;
    }
    
    public void setInterests(List<String> interests) {
        this.interests = interests;
    }
    
    public String getPrivacySettings() {
        return privacySettings;
    }
    
    public void setPrivacySettings(String privacySettings) {
        this.privacySettings = privacySettings;
    }
    
    public Boolean getIsPublicProfile() {
        return isPublicProfile;
    }
    
    public void setIsPublicProfile(Boolean isPublicProfile) {
        this.isPublicProfile = isPublicProfile;
    }
    
    public Boolean getAllowMessages() {
        return allowMessages;
    }
    
    public void setAllowMessages(Boolean allowMessages) {
        this.allowMessages = allowMessages;
    }
    
    public Boolean getShowOnlineStatus() {
        return showOnlineStatus;
    }
    
    public void setShowOnlineStatus(Boolean showOnlineStatus) {
        this.showOnlineStatus = showOnlineStatus;
    }
    
    public Integer getFollowersCount() {
        return followersCount;
    }
    
    public void setFollowersCount(Integer followersCount) {
        this.followersCount = followersCount;
    }
    
    public Integer getFollowingCount() {
        return followingCount;
    }
    
    public void setFollowingCount(Integer followingCount) {
        this.followingCount = followingCount;
    }
    
    public Integer getPostsCount() {
        return postsCount;
    }
    
    public void setPostsCount(Integer postsCount) {
        this.postsCount = postsCount;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    @Override
    public String toString() {
        return "Profile{" +
                "id=" + id +
                ", bio='" + bio + '\'' +
                ", location='" + location + '\'' +
                ", isPublicProfile=" + isPublicProfile +
                ", followersCount=" + followersCount +
                ", followingCount=" + followingCount +
                ", postsCount=" + postsCount +
                ", createdAt=" + createdAt +
                '}';
    }
}

