package com.flower.backend.service;

import com.flower.backend.entity.User;
import com.flower.backend.entity.Profile;
import com.flower.backend.repository.UserRepository;
import com.flower.backend.repository.ProfileRepository;
import com.flower.backend.security.UserPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserService implements UserDetailsService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ProfileRepository profileRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Override
    @Transactional
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Primeiro, tenta encontrar por email
        Optional<User> userOptional = userRepository.findByEmail(username);
        
        // Se não encontrar por email, tenta por ID (para JWT)
        if (userOptional.isEmpty()) {
            try {
                UUID userId = UUID.fromString(username);
                userOptional = userRepository.findById(userId);
            } catch (IllegalArgumentException e) {
                // Não é um UUID válido, continua com a busca por email
            }
        }
        
        User user = userOptional.orElseThrow(() -> 
            new UsernameNotFoundException("Usuária não encontrada: " + username));
        
        return UserPrincipal.create(user);
    }
    
    @Transactional
    public User createUser(String email, String password, String fullName) {
        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("Email já está em uso");
        }
        
        User user = new User();
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(password));
        user.setFullName(fullName);
        user.setIsVerified(false);
        user.setVerificationStatus(User.VerificationStatus.PENDING);
        user.setIsActive(true);
        
        User savedUser = userRepository.save(user);
        
        // Criar perfil padrão para a usuária
        Profile profile = new Profile(savedUser);
        profileRepository.save(profile);
        
        return savedUser;
    }
    
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    public Optional<User> findById(UUID id) {
        return userRepository.findById(id);
    }
    
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }
    
    @Transactional
    public User updateUser(UUID userId, User updatedUser) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
        
        if (updatedUser.getFullName() != null) {
            user.setFullName(updatedUser.getFullName());
        }
        if (updatedUser.getPhone() != null) {
            user.setPhone(updatedUser.getPhone());
        }
        if (updatedUser.getBirthDate() != null) {
            user.setBirthDate(updatedUser.getBirthDate());
        }
        
        return userRepository.save(user);
    }
    
    @Transactional
    public void updateLastLogin(UUID userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
        
        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);
    }
    
    @Transactional
    public User verifyUser(UUID userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
        
        user.setIsVerified(true);
        user.setVerificationStatus(User.VerificationStatus.APPROVED);
        
        return userRepository.save(user);
    }
    
    @Transactional
    public User rejectUserVerification(UUID userId, String reason) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
        
        user.setVerificationStatus(User.VerificationStatus.REJECTED);
        
        return userRepository.save(user);
    }
    
    public List<User> findAllVerifiedAndActiveUsers() {
        return userRepository.findAllVerifiedAndActiveUsers();
    }
    
    public List<User> findByVerificationStatus(User.VerificationStatus status) {
        return userRepository.findByVerificationStatus(status);
    }
    
    public List<User> findUsersCreatedAfter(LocalDateTime date) {
        return userRepository.findUsersCreatedAfter(date);
    }
    
    public long countVerifiedUsers() {
        return userRepository.countVerifiedUsers();
    }
    
    public long countUsersCreatedAfter(LocalDateTime date) {
        return userRepository.countUsersCreatedAfter(date);
    }
    
    public List<User> searchUsersByName(String name) {
        return userRepository.findByFullNameContainingIgnoreCase(name);
    }
    
    public List<User> findInactiveUsers(LocalDateTime cutoffDate) {
        return userRepository.findInactiveUsers(cutoffDate);
    }
    
    @Transactional
    public void deactivateUser(UUID userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
        
        user.setIsActive(false);
        userRepository.save(user);
    }
    
    @Transactional
    public void activateUser(UUID userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
        
        user.setIsActive(true);
        userRepository.save(user);
    }
    
    @Transactional
    public boolean changePassword(UUID userId, String currentPassword, String newPassword) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
        
        if (!passwordEncoder.matches(currentPassword, user.getPasswordHash())) {
            return false;
        }
        
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepository.save(user);
        
        return true;
    }
}

