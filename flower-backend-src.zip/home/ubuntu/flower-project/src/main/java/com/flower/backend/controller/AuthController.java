package com.flower.backend.controller;

import com.flower.backend.dto.*;
import com.flower.backend.entity.User;
import com.flower.backend.security.JwtTokenProvider;
import com.flower.backend.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AuthController {
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private JwtTokenProvider tokenProvider;
    
    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    loginRequest.getEmail(),
                    loginRequest.getPassword()
                )
            );
            
            SecurityContextHolder.getContext().setAuthentication(authentication);
            
            String jwt = tokenProvider.generateToken(authentication);
            String refreshToken = tokenProvider.generateRefreshToken(authentication);
            
            // Buscar usuária para resposta
            User user = userService.findByEmail(loginRequest.getEmail())
                .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
            
            // Atualizar último login
            userService.updateLastLogin(user.getId());
            
            UserResponse userResponse = new UserResponse(user);
            JwtAuthenticationResponse response = new JwtAuthenticationResponse(jwt, refreshToken, userResponse);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Credenciais inválidas");
            error.put("message", "Email ou senha incorretos");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
        }
    }
    
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody RegisterRequest registerRequest) {
        try {
            if (userService.existsByEmail(registerRequest.getEmail())) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "Email já está em uso");
                error.put("message", "Este email já está cadastrado na plataforma");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
            }
            
            User user = userService.createUser(
                registerRequest.getEmail(),
                registerRequest.getPassword(),
                registerRequest.getFullName()
            );
            
            // Definir dados opcionais
            if (registerRequest.getBirthDate() != null) {
                user.setBirthDate(registerRequest.getBirthDate());
            }
            if (registerRequest.getPhone() != null) {
                user.setPhone(registerRequest.getPhone());
            }
            
            UserResponse userResponse = new UserResponse(user);
            
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Usuária registrada com sucesso! Aguarde a verificação de identidade.");
            response.put("user", userResponse);
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
            
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Erro no registro");
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }
    
    @PostMapping("/refresh")
    public ResponseEntity<?> refreshToken(@RequestBody Map<String, String> request) {
        try {
            String refreshToken = request.get("refreshToken");
            
            if (refreshToken == null || !tokenProvider.validateToken(refreshToken)) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "Token de refresh inválido");
                error.put("message", "Token de refresh expirado ou inválido");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            }
            
            // Extrair ID da usuária do refresh token
            java.util.UUID userId = tokenProvider.getUserIdFromToken(refreshToken);
            User user = userService.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
            
            // Criar nova autenticação
            Authentication authentication = new UsernamePasswordAuthenticationToken(
                user.getEmail(), null, null);
            
            String newAccessToken = tokenProvider.generateToken(authentication);
            String newRefreshToken = tokenProvider.generateRefreshToken(authentication);
            
            UserResponse userResponse = new UserResponse(user);
            JwtAuthenticationResponse response = new JwtAuthenticationResponse(
                newAccessToken, newRefreshToken, userResponse);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Erro ao renovar token");
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
        }
    }
    
    @PostMapping("/logout")
    public ResponseEntity<?> logoutUser() {
        // Por enquanto, apenas limpa o contexto de segurança
        // Em uma implementação completa, adicionaríamos o token a uma blacklist
        SecurityContextHolder.clearContext();
        
        Map<String, String> response = new HashMap<>();
        response.put("message", "Logout realizado com sucesso");
        
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(Authentication authentication) {
        try {
            if (authentication == null) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "Não autenticado");
                error.put("message", "Token de acesso necessário");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            }
            
            String email = authentication.getName();
            User user = userService.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuária não encontrada"));
            
            UserResponse userResponse = new UserResponse(user);
            return ResponseEntity.ok(userResponse);
            
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Erro ao buscar usuária");
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }
}

