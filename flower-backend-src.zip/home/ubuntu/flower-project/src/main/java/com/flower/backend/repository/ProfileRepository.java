package com.flower.backend.repository;

import com.flower.backend.entity.Profile;
import com.flower.backend.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface ProfileRepository extends JpaRepository<Profile, UUID> {
    
    Optional<Profile> findByUserId(UUID userId);
    
    Optional<Profile> findByUser(User user);
    
    @Query("SELECT p FROM Profile p WHERE p.isPublicProfile = true")
    List<Profile> findAllPublicProfiles();
    
    @Query("SELECT p FROM Profile p WHERE p.location ILIKE %:location%")
    List<Profile> findByLocationContainingIgnoreCase(@Param("location") String location);
    
    @Query("SELECT p FROM Profile p WHERE :interest MEMBER OF p.interests")
    List<Profile> findByInterestsContaining(@Param("interest") String interest);
    
    @Query("SELECT p FROM Profile p WHERE p.followersCount >= :minFollowers ORDER BY p.followersCount DESC")
    List<Profile> findByMinFollowersOrderByFollowersDesc(@Param("minFollowers") Integer minFollowers);
    
    @Query("SELECT p FROM Profile p WHERE p.postsCount >= :minPosts ORDER BY p.postsCount DESC")
    List<Profile> findByMinPostsOrderByPostsDesc(@Param("minPosts") Integer minPosts);
    
    @Query("SELECT p FROM Profile p WHERE p.user.isVerified = true AND p.isPublicProfile = true ORDER BY p.followersCount DESC")
    List<Profile> findTopVerifiedProfiles();
}

