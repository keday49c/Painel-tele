package com.flower.backend.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "communities")
public class Community {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;
    
    @Column(nullable = false)
    @NotBlank(message = "Nome da comunidade é obrigatório")
    @Size(max = 255, message = "Nome deve ter no máximo 255 caracteres")
    private String name;
    
    @Column(columnDefinition = "TEXT")
    @Size(max = 2000, message = "Descrição deve ter no máximo 2000 caracteres")
    private String description;
    
    @Column(length = 100)
    @Enumerated(EnumType.STRING)
    private CommunityCategory category;
    
    @Column(name = "is_private", nullable = false)
    private Boolean isPrivate = false;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "creator_id")
    private User creator;
    
    @Column(name = "member_count", nullable = false)
    private Integer memberCount = 0;
    
    @Column(name = "posts_count", nullable = false)
    private Integer postsCount = 0;
    
    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;
    
    @Column(name = "community_image_url", length = 500)
    private String communityImageUrl;
    
    @Column(name = "rules", columnDefinition = "TEXT")
    private String rules;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    // Enum for community categories
    public enum CommunityCategory {
        EMPREENDEDORISMO,
        CARREIRA,
        MATERNIDADE,
        BEM_ESTAR,
        SAUDE_MENTAL,
        FINANCAS,
        TECNOLOGIA,
        ARTE_CULTURA,
        EDUCACAO,
        NETWORKING,
        LIFESTYLE,
        OUTROS
    }
    
    // Constructors
    public Community() {}
    
    public Community(String name, String description, User creator) {
        this.name = name;
        this.description = description;
        this.creator = creator;
    }
    
    // Getters and Setters
    public UUID getId() {
        return id;
    }
    
    public void setId(UUID id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public CommunityCategory getCategory() {
        return category;
    }
    
    public void setCategory(CommunityCategory category) {
        this.category = category;
    }
    
    public Boolean getIsPrivate() {
        return isPrivate;
    }
    
    public void setIsPrivate(Boolean isPrivate) {
        this.isPrivate = isPrivate;
    }
    
    public User getCreator() {
        return creator;
    }
    
    public void setCreator(User creator) {
        this.creator = creator;
    }
    
    public Integer getMemberCount() {
        return memberCount;
    }
    
    public void setMemberCount(Integer memberCount) {
        this.memberCount = memberCount;
    }
    
    public Integer getPostsCount() {
        return postsCount;
    }
    
    public void setPostsCount(Integer postsCount) {
        this.postsCount = postsCount;
    }
    
    public Boolean getIsActive() {
        return isActive;
    }
    
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    
    public String getCommunityImageUrl() {
        return communityImageUrl;
    }
    
    public void setCommunityImageUrl(String communityImageUrl) {
        this.communityImageUrl = communityImageUrl;
    }
    
    public String getRules() {
        return rules;
    }
    
    public void setRules(String rules) {
        this.rules = rules;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    @Override
    public String toString() {
        return "Community{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", category=" + category +
                ", isPrivate=" + isPrivate +
                ", memberCount=" + memberCount +
                ", postsCount=" + postsCount +
                ", isActive=" + isActive +
                ", createdAt=" + createdAt +
                '}';
    }
}

