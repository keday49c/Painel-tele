package com.flower.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlowerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
