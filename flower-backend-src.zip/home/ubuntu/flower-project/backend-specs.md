# Especificações Técnicas do Backend - Flower

## Arquitetura Geral

### Stack Tecnológica
- **Linguagem Principal:** Java 17+ (Spring Boot)
- **Framework:** Spring Boot 3.x
- **Banco de Dados:** PostgreSQL (principal) + Redis (cache)
- **Autenticação:** JWT + OAuth2
- **Segurança:** Spring Security
- **API:** RESTful APIs
- **Documentação:** OpenAPI/Swagger
- **Containerização:** Docker
- **Monitoramento:** Spring Actuator

### Arquitetura de Microserviços

#### 1. Serviço de Autenticação e Autorização (Auth Service)
- **Responsabilidades:**
  - Registro e login de usuárias
  - Verificação de identidade feminina
  - Geração e validação de tokens JWT
  - Gerenciamento de sessões
  - Integração com verificação facial

- **Endpoints Principais:**
  - POST /api/auth/register
  - POST /api/auth/login
  - POST /api/auth/verify-identity
  - POST /api/auth/refresh-token
  - POST /api/auth/logout

#### 2. Serviço de Usuárias (User Service)
- **Responsabilidades:**
  - Gerenciamento de perfis de usuárias
  - Configurações de privacidade
  - Histórico de atividades
  - Preferências personalizadas

- **Endpoints Principais:**
  - GET /api/users/profile
  - PUT /api/users/profile
  - GET /api/users/{id}
  - PUT /api/users/settings
  - GET /api/users/activity

#### 3. Serviço de Comunidades (Community Service)
- **Responsabilidades:**
  - Criação e gerenciamento de comunidades
  - Moderação de conteúdo
  - Participação em grupos
  - Estatísticas de engajamento

- **Endpoints Principais:**
  - GET /api/communities
  - POST /api/communities
  - GET /api/communities/{id}
  - POST /api/communities/{id}/join
  - DELETE /api/communities/{id}/leave

#### 4. Serviço de Conteúdo (Content Service)
- **Responsabilidades:**
  - Gerenciamento de posts e comentários
  - Feed personalizado
  - Algoritmo de recomendação
  - Moderação automática

- **Endpoints Principais:**
  - GET /api/content/feed
  - POST /api/content/posts
  - GET /api/content/posts/{id}
  - POST /api/content/posts/{id}/comments
  - PUT /api/content/posts/{id}/like

#### 5. Serviço de Trilhas (Learning Service)
- **Responsabilidades:**
  - Gerenciamento de trilhas de desenvolvimento
  - Progresso de aprendizado
  - Certificações
  - Recomendações personalizadas

- **Endpoints Principais:**
  - GET /api/learning/tracks
  - GET /api/learning/tracks/{id}
  - POST /api/learning/tracks/{id}/enroll
  - PUT /api/learning/progress
  - GET /api/learning/certificates

#### 6. Serviço de Marketplace (Marketplace Service)
- **Responsabilidades:**
  - Catálogo de produtos e serviços
  - Transações e pagamentos
  - Avaliações e reviews
  - Comissões

- **Endpoints Principais:**
  - GET /api/marketplace/products
  - POST /api/marketplace/products
  - POST /api/marketplace/orders
  - GET /api/marketplace/orders/{id}
  - POST /api/marketplace/reviews

## Segurança

### Medidas de Segurança Implementadas

#### 1. Autenticação e Autorização
- **JWT Tokens:** Tokens seguros com expiração configurável
- **Refresh Tokens:** Para renovação automática de sessões
- **Role-Based Access Control (RBAC):** Diferentes níveis de acesso
- **OAuth2:** Integração com provedores externos (Google, Facebook)

#### 2. Proteção de Dados
- **Criptografia:** Todas as senhas hasheadas com BCrypt
- **HTTPS:** Comunicação criptografada obrigatória
- **Validação de Entrada:** Sanitização de todos os inputs
- **Rate Limiting:** Proteção contra ataques de força bruta

#### 3. Verificação de Identidade Feminina
- **Análise de Documentos:** Verificação de RG/CPF
- **Reconhecimento Facial:** Comparação com documento oficial
- **Análise Comportamental:** Padrões de uso para detecção de anomalias
- **Verificação Manual:** Revisão humana quando necessário

#### 4. Moderação e Segurança de Conteúdo
- **Filtros Automáticos:** IA para detecção de conteúdo inadequado
- **Moderação Humana:** Equipe especializada em questões femininas
- **Sistema de Denúncias:** Processo rápido e eficiente
- **Blacklist de Palavras:** Lista atualizada de termos proibidos

## Banco de Dados

### Estrutura Principal (PostgreSQL)

#### Tabelas Principais:

```sql
-- Usuárias
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    birth_date DATE,
    phone VARCHAR(20),
    is_verified BOOLEAN DEFAULT FALSE,
    verification_status VARCHAR(50) DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Perfis
CREATE TABLE profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    bio TEXT,
    profile_image_url VARCHAR(500),
    location VARCHAR(255),
    interests TEXT[],
    privacy_settings JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Comunidades
CREATE TABLE communities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    is_private BOOLEAN DEFAULT FALSE,
    creator_id UUID REFERENCES users(id),
    member_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Posts
CREATE TABLE posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    community_id UUID REFERENCES communities(id),
    title VARCHAR(500),
    content TEXT NOT NULL,
    media_urls TEXT[],
    likes_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    is_moderated BOOLEAN DEFAULT FALSE,
    moderation_status VARCHAR(50) DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Trilhas de Desenvolvimento
CREATE TABLE learning_tracks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    difficulty_level VARCHAR(50),
    estimated_duration INTEGER, -- em horas
    price DECIMAL(10,2) DEFAULT 0,
    is_premium BOOLEAN DEFAULT FALSE,
    creator_id UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Cache (Redis)
- **Sessões de usuárias:** Tokens JWT e dados de sessão
- **Feed personalizado:** Cache do feed de cada usuária
- **Estatísticas:** Contadores de likes, views, etc.
- **Rate Limiting:** Controle de requisições por IP/usuária

## APIs e Integração

### APIs Externas Integradas
1. **Serviço de Verificação Facial:** AWS Rekognition ou Azure Face API
2. **Processamento de Pagamentos:** Stripe ou PagSeguro
3. **Envio de E-mails:** SendGrid ou Amazon SES
4. **Armazenamento de Mídia:** AWS S3 ou Cloudinary
5. **Notificações Push:** Firebase Cloud Messaging

### Documentação da API
- **OpenAPI 3.0:** Especificação completa da API
- **Swagger UI:** Interface interativa para testes
- **Postman Collection:** Coleção para desenvolvedores

## Configuração de Ambiente

### Variáveis de Ambiente
```properties
# Database
DATABASE_URL=postgresql://localhost:5432/flower_db
DATABASE_USERNAME=flower_user
DATABASE_PASSWORD=secure_password

# Redis
REDIS_URL=redis://localhost:6379
REDIS_PASSWORD=redis_password

# JWT
JWT_SECRET=your_jwt_secret_key_here
JWT_EXPIRATION=86400000

# External APIs
AWS_ACCESS_KEY_ID=your_aws_key
AWS_SECRET_ACCESS_KEY=your_aws_secret
STRIPE_SECRET_KEY=your_stripe_key

# Email
SENDGRID_API_KEY=your_sendgrid_key
FROM_EMAIL=noreply@flower.com
```

## Monitoramento e Logs

### Métricas Importantes
- **Performance:** Tempo de resposta das APIs
- **Disponibilidade:** Uptime dos serviços
- **Segurança:** Tentativas de acesso não autorizado
- **Uso:** Número de usuárias ativas, posts, etc.

### Logs Estruturados
- **Formato JSON:** Para facilitar análise
- **Níveis:** ERROR, WARN, INFO, DEBUG
- **Contexto:** User ID, Request ID, Timestamp

## Escalabilidade

### Estratégias de Escalabilidade
1. **Load Balancing:** Distribuição de carga entre instâncias
2. **Database Sharding:** Particionamento horizontal do banco
3. **Caching Inteligente:** Cache em múltiplas camadas
4. **CDN:** Para conteúdo estático e mídia
5. **Auto-scaling:** Ajuste automático de recursos

### Performance Targets
- **Tempo de Resposta:** < 200ms para 95% das requisições
- **Throughput:** 1000+ requisições por segundo
- **Disponibilidade:** 99.9% uptime
- **Latência do Feed:** < 100ms para carregamento inicial

